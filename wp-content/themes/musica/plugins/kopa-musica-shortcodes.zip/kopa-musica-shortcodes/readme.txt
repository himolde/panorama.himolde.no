===Kopa Shortcodes===

Contributors: Kopatheme
Tags: shortcodes
License: GPLv2 or later
Since: Musica v1.0

A plugin to generate shortcodes in the WordPress visual editor.
Note: Specific use in Musica Theme

